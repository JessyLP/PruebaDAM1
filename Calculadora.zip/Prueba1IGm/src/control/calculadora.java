package control;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;

import javax.swing.AbstractButton;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JTextField;

import vista.CalculadoraIgual;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class calculadora {

	private JFrame frame;
	private JTextField textFieldCalcular;
	private int calculo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					calculadora window = new calculadora();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public calculadora() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panelOeste = new JPanel();
		frame.getContentPane().add(panelOeste, BorderLayout.WEST);
		
		JButton btnDelete = new JButton("CC");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText("");
			}
		});
		panelOeste.add(btnDelete);
		
		JPanel panelNorte = new JPanel();
		frame.getContentPane().add(panelNorte, BorderLayout.NORTH);
		panelNorte.setLayout(new GridLayout(0, 1, 0, 0));
		
		textFieldCalcular = new JTextField();
		textFieldCalcular.setFont(new Font("Dialog", Font.PLAIN, 19));
		panelNorte.add(textFieldCalcular);
		textFieldCalcular.setColumns(10);
		
		JPanel panelSur = new JPanel();
		panelSur.setForeground(SystemColor.desktop);
		frame.getContentPane().add(panelSur, BorderLayout.SOUTH);
		panelSur.setLayout(new GridLayout(0, 1, 0, 0));
		
		JButton btn0 = new JButton("0");
		btn0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "0");
			}
		});
		btn0.setFont(new Font("Dialog", Font.BOLD, 20));
		panelSur.add(btn0);
		
		JPanel panelEste = new JPanel();
		frame.getContentPane().add(panelEste, BorderLayout.EAST);
		panelEste.setLayout(new GridLayout(0, 1, 0, 0));
		
		JButton btnSuma = new JButton("+");
		btnSuma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + " + ");
			}
		});
		btnSuma.setFont(new Font("Dialog", Font.BOLD, 20));
		panelEste.add(btnSuma);
		
		JButton btnResta = new JButton("-");
		btnResta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + " - ");
			}
		});
		btnResta.setFont(new Font("Dialog", Font.BOLD, 20));
		panelEste.add(btnResta);
		
		JButton btnMulti = new JButton("*");
		btnMulti.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + " * ");
			}
		});
		btnMulti.setFont(new Font("Dialog", Font.BOLD, 20));
		panelEste.add(btnMulti);
		
		JButton btnDivi = new JButton("/");
		btnDivi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + " / ");
			}
		});
		btnDivi.setFont(new Font("Dialog", Font.BOLD, 20));
		panelEste.add(btnDivi);
		
		JButton btnIgual = new JButton("=");
		btnIgual.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				CalculadoraIgual ventanaIgual = new CalculadoraIgual(textFieldCalcular);
				ventanaIgual.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				ventanaIgual.setModal(true);
				ventanaIgual.setVisible(true);
			}
		});
		btnIgual.setFont(new Font("Dialog", Font.BOLD, 20));
		panelEste.add(btnIgual);
		
		JPanel panelCentro = new JPanel();
		frame.getContentPane().add(panelCentro, BorderLayout.CENTER);
		panelCentro.setLayout(new GridLayout(0, 3, 0, 0));
		
		JButton btn7 = new JButton("7");
		btn7.setForeground(Color.WHITE);
		btn7.setBackground(Color.BLUE);
		btn7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "7");
			}
		});
		panelCentro.add(btn7);
		
		JButton btn8 = new JButton("8");
		btn8.setForeground(Color.WHITE);
		btn8.setBackground(Color.BLUE);
		btn8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "8");
			}
		});
		panelCentro.add(btn8);
		
		JButton btn9 = new JButton("9");
		btn9.setBackground(Color.BLUE);
		btn9.setForeground(Color.WHITE);
		btn9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "9");
			}
		});
		panelCentro.add(btn9);
		
		JButton btn4 = new JButton("4");
		btn4.setBackground(Color.CYAN);
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "4");
			}
		});
		panelCentro.add(btn4);
		
		JButton btn5 = new JButton("5");
		btn5.setBackground(Color.CYAN);
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "5");
			}
		});
		panelCentro.add(btn5);
		
		JButton btn6 = new JButton("6");
		btn6.setBackground(Color.CYAN);
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "6");
			}
		});
		panelCentro.add(btn6);
		
		JButton btn1 = new JButton("1");
		btn1.setForeground(Color.WHITE);
		btn1.setBackground(Color.BLUE);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "1");
			}
		});
		btn1.setFont(new Font("Dialog", Font.BOLD, 12));
		panelCentro.add(btn1);
		
		JButton btn2 = new JButton("2");
		btn2.setForeground(Color.WHITE);
		btn2.setBackground(Color.BLUE);
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "2");
			}
		});
		panelCentro.add(btn2);
		
		JButton btn3 = new JButton("3");
		btn3.setForeground(Color.WHITE);
		btn3.setBackground(Color.BLUE);
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textFieldCalcular.setText(textFieldCalcular.getText() + "3");
			}
		});
		panelCentro.add(btn3);
	}
}

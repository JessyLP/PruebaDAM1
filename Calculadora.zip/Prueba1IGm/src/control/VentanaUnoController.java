package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import vista.NuevaVentana;

public class VentanaUnoController implements ActionListener{
	
	private JTextField cajaTexto=new JTextField();

	

	public VentanaUnoController(JTextField cajaTexto) {
		super();
		this.cajaTexto=cajaTexto;
		
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		String opcion= e.getActionCommand();
		
		
		switch(opcion) {
			case "MiBoton":{
				JOptionPane.showMessageDialog(null, "He pinchado el botón" +cajaTexto.getText() , "Mensaje en la barra de titulo" , JOptionPane.INFORMATION_MESSAGE);
				
				cajaTexto.setText("Heeeeeey");
				
			};break;
			
			case "NuevaVentana" : {
				JTextField text = new JTextField(cajaTexto.getText());
				NuevaVentana nuevaVentana = new NuevaVentana(text);
				nuevaVentana.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				nuevaVentana.setModal(true);
				nuevaVentana.setVisible(true);
				}
			break;
		}
		
	
		
	}
	

}

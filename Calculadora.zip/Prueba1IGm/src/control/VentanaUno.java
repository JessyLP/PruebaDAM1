package control;


import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;

import vista.NuevaVentana;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.FlowLayout;
import javax.swing.JPanel;
import javax.swing.BoxLayout;
import java.awt.GridLayout;
import java.awt.Color;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JMenu;

public class VentanaUno extends JFrame{

	//private JFrame frame;
	private JPanel panelNorte;
	private JLabel lblTitulo;
	private JPanel panelOeste;
	private JPanel panelSur;
	private JPanel PanelEste;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;
	private JTextField txtCampoTexto;
	private JButton btnNewButton_3;
	private JButton btnMiBoton;
	private JTextField textField_1;
	private JButton btnNewButton_5;
	private JButton btnNewButton_6;
	private JPanel panelCentral;
	private JButton btnNuevaVentana;
	private JButton btnNewButton_7;
	private JButton btnNewButton_8;
	private JButton btnNewButton_9;
	private JMenuBar menuBar;
	private JMenuItem mntmNewMenuItem;
	private JMenu mnNewMenu;
	private JMenu mnHi;

	

	/**
	 * Create the application.
	 */
	public VentanaUno() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		txtCampoTexto = new JTextField();
		txtCampoTexto.setText("");
		txtCampoTexto.setColumns(10);
		
		getContentPane().setFont(new Font("Dialog", Font.PLAIN, 21));
		setBounds(570, 300, 651, 391);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout(0, 0));
		
		panelNorte = new JPanel();
		getContentPane().add(panelNorte, BorderLayout.NORTH);
		panelNorte.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		lblTitulo = new JLabel("Etiqueta");
		panelNorte.add(lblTitulo);
		
		btnMiBoton = new JButton("mi Botón.");
		btnMiBoton.setActionCommand("MiBoton");
		btnMiBoton.addActionListener(new VentanaUnoController(txtCampoTexto));
		
		panelNorte.add(btnMiBoton);
		
		panelOeste = new JPanel();
		getContentPane().add(panelOeste, BorderLayout.WEST);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Dialog", Font.PLAIN, 9));
		textField_1.setText("");
		textField_1.setColumns(10);
		panelOeste.add(textField_1);
		
		btnNewButton_5 = new JButton("Botón5.");
		btnNewButton_5.setFont(new Font("Dialog", Font.BOLD, 9));
		panelOeste.add(btnNewButton_5);
		
		btnNewButton_6 = new JButton("Botón6.");
		btnNewButton_6.setFont(new Font("Dialog", Font.BOLD, 9));
		panelOeste.add(btnNewButton_6);
		
		panelSur = new JPanel();
		panelSur.setBackground(Color.DARK_GRAY);
		getContentPane().add(panelSur, BorderLayout.SOUTH);
		panelSur.setLayout(new BoxLayout(panelSur, BoxLayout.X_AXIS));
		
		btnNewButton_1 = new JButton("Botón1.");
		panelSur.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("Botón2.");
		panelSur.add(btnNewButton_2);
		
		PanelEste = new JPanel();
		getContentPane().add(PanelEste, BorderLayout.EAST);
		PanelEste.setLayout(new BoxLayout(PanelEste, BoxLayout.Y_AXIS));
		
		
		
		
		PanelEste.add(txtCampoTexto);
		
		btnNewButton_3 = new JButton("Botón3.");
		PanelEste.add(btnNewButton_3);
		
		panelCentral = new JPanel();
		getContentPane().add(panelCentral, BorderLayout.CENTER);
		panelCentral.setLayout(new GridLayout(0, 3, 0, 0));
		
		btnNuevaVentana = new JButton("NUEVA VENTANA");
		btnNuevaVentana.setActionCommand("NuevaVentana");
		btnNuevaVentana.addActionListener(new VentanaUnoController(txtCampoTexto));
		panelCentral.add(btnNuevaVentana);
		
		btnNewButton_7 = new JButton("Botó7.");
		panelCentral.add(btnNewButton_7);
		
		btnNewButton_8 = new JButton("Botó8.");
		panelCentral.add(btnNewButton_8);
		
		btnNewButton_9 = new JButton("Botó9.");
		panelCentral.add(btnNewButton_9);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		mnNewMenu = new JMenu("Abrir");
		mnNewMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Mensaje más básico");
			}
		});
		menuBar.add(mnNewMenu);
		
		mnHi = new JMenu("hi");
		mnNewMenu.add(mnHi);
		
		
		mntmNewMenuItem = new JMenuItem("Salir");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		menuBar.add(mntmNewMenuItem);
	}
}

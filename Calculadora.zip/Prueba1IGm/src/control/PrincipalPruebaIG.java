package control;

import java.awt.EventQueue;

public class PrincipalPruebaIG {
	/*
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaUno window = new VentanaUno();
					/*Windows va a ser en si mismo un JFrame, por que extiente de la clase ventanaUno*/
					/*El objeto windows ya viene implementado con el JFrame*/
					window.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}

package vista;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NuevaVentana extends JDialog {
	private JTextField textField;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public NuevaVentana(JTextField txtCampoTexto) {
		/*x,y,ancho,alto en px*/
		setBounds(575, 300, 450, 300);
		
		
		JLabel lblNuevaVentana = new JLabel("Nueva Ventana");
		getContentPane().add(lblNuevaVentana, BorderLayout.NORTH);
		
		textField = new JTextField(txtCampoTexto.getText());
		getContentPane().add(textField, BorderLayout.CENTER);
		textField.setColumns(10);
		//textField.setText("La información va aqui");
		JOptionPane.showMessageDialog(null, "He pinchado el botón" + txtCampoTexto.getText(), "Mensaje en la barra de titulo" , JOptionPane.INFORMATION_MESSAGE);
		
		
		JButton btnBoton1 = new JButton("Boton");
		btnBoton1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				JOptionPane.showMessageDialog(null, "He pinchado en el botón");
				
			}
		});
		getContentPane().add(btnBoton1, BorderLayout.SOUTH);
		

	}

}

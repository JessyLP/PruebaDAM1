package vista;

import java.awt.EventQueue;

import javax.swing.JDialog;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JTextField;

public class CalculadoraIgual extends JDialog {
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public CalculadoraIgual(JTextField textFieldCalcular) {
		setBounds(100, 100, 249, 148);
		
		JLabel lblCalcular = new JLabel("Calcular:");
		getContentPane().add(lblCalcular, BorderLayout.NORTH);
		
		textField = new JTextField(textFieldCalcular.getText());
		getContentPane().add(textField, BorderLayout.CENTER);
		textField.setColumns(10);
		textField.setText(textFieldCalcular.getText() + " = ");

	}

}
